//
//  CustNaviagationController.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 27/02/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit

class CustNaviagationController: UINavigationController,UIGestureRecognizerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
//        self.navigationController?.interactivePopGestureRecognizer?.delegate = self
//           self.navigationController?.delegate = self
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
