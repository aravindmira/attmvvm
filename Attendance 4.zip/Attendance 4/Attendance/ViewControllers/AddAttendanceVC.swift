//
//  AddAttendanceVC.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 11/02/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit

class AddAttendanceVC: UIViewController {
     var positionStr = String()
    @IBOutlet weak var PSignImgView: UIImageView!
    
    @IBOutlet weak var PositionTF: UITextField!
    @IBOutlet weak var NameTF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        let value = UIInterfaceOrientation.portrait.rawValue
        UIDevice.current.setValue(value, forKey: "orientation")
       
    }
    override func viewDidAppear(_ animated: Bool) {
        self.PositionTF.text = positionStr
    }
    
    @IBAction func BackBT(_ sender: Any) {
        dismiss(animated: true, completion: nil)
                      navigationController?.popViewController(animated: true)
    }
    @IBAction func Action(_ sender: Any) {
       
    }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    func convertBase64ToImage(_ str: String) -> UIImage {
            let dataDecoded : Data = Data(base64Encoded: str, options: .ignoreUnknownCharacters)!
            let decodedimage = UIImage(data: dataDecoded)
            return decodedimage!
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "callback"{
                let pop = segue.destination as!SignatureVC
              
    
                 pop.onSave = {(_ data:String)->()  in
                    self.PSignImgView.image = self.convertBase64ToImage(data)
                    print(data)
                        }
   
            }
        }

}

