//
//  SignatureVC.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 12/02/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit

class SignatureVC: UIViewController, YPSignatureDelegate {
@IBOutlet weak var signatureView: YPDrawSignatureView!
    var imageStr = String()
    var onSave:((_ data:String)->())?
    override func viewDidLoad() {
        super.viewDidLoad()
        signatureView.delegate = self as? YPSignatureDelegate

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        var value : Int = UIInterfaceOrientation.landscapeRight.rawValue
               if UIApplication.shared.statusBarOrientation == .portrait || UIApplication.shared.statusBarOrientation == .portraitUpsideDown{
                  value = UIInterfaceOrientation.landscapeRight.rawValue
               }
               UIDevice.current.setValue(value, forKey: "orientation")
               UIViewController.attemptRotationToDeviceOrientation()
    }
    
    func didStart(_ view : YPDrawSignatureView) {
        print("Started Drawing")
    }
    
    func didFinish(_ view : YPDrawSignatureView) {
        print("Finished Drawing")
        
    }
    @IBAction func ClearBT(_ sender: Any) {
         self.signatureView.clear()
    }
    @IBAction func SaveBT(_ sender: Any) {
    if let signatureImage = self.signatureView.getSignature(scale: 10) {
       // UIImageWriteToSavedPhotosAlbum(signatureImage, nil, nil, nil)
       imageStr = convertImageToBase64(signatureImage)
        onSave?(imageStr)
        changeToPortrair()
         navigationController?.popViewController(animated: true)
    }
    }
    @IBAction func CancelBT(_ sender: Any) {
        changeToPortrair()
        dismiss(animated: true, completion: nil)
         navigationController?.popViewController(animated: true)
    }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.landscapeRight
    }
    func convertImageToBase64(_ image: UIImage) -> String {
        let imageData:NSData = image.jpegData(compressionQuality: 0.4)! as NSData
           let strBase64 = imageData.base64EncodedString(options: .lineLength64Characters)
           return strBase64
    }
    
    func changeToPortrair()  {
        var value : Int = UIInterfaceOrientation.landscapeRight.rawValue
        if UIApplication.shared.statusBarOrientation == .landscapeLeft || UIApplication.shared.statusBarOrientation == .landscapeRight{
           value = UIInterfaceOrientation.portrait.rawValue
        }
        UIDevice.current.setValue(value, forKey: "orientation")
        UIViewController.attemptRotationToDeviceOrientation()
    }
}
