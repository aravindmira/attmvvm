//
//  ViewController.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 23/01/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDataSource,UIPickerViewDelegate,UITextFieldDelegate {

    private var lvm = LoginViewModel()
    @IBOutlet weak var RegionPicker: UIPickerView!
    @IBOutlet var UserNameTF: UITextField!
    @IBOutlet weak var PassWordTF: UITextField!
    @IBOutlet weak var ActIng: UIActivityIndicatorView!
    @IBOutlet weak var LogInBT: UIButton!
    @IBOutlet weak var RegLbl: UILabel!
    @IBOutlet weak var RegionTF: UITextField!
    var tempArr = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.ActIng.isHidden = true
        self.ActIng.transform = CGAffineTransform(scaleX: 1.5, y: 1.5)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
//        self.RegionTF.removeFromSuperview()
//        self.RegLbl.isHidden = true
        
        tempArr = ["sdsdas","asdasdsad","asdasdsd","dfdsfdsf"]
        self.RegionTF.inputView = RegionPicker
        self.RegionTF.addDoneButtonOnKeyboard()
        
        let value = UIInterfaceOrientation.portrait.rawValue
        UIDevice.current.setValue(value, forKey: "orientation")
        self.UserNameTF.text = "erica"
        self.PassWordTF.text = "1234"

    }
   @objc func keyboardWillShow(notification: NSNotification) {
       if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
           if self.view.frame.origin.y == 0 {
               self.view.frame.origin.y -= keyboardSize.height-100
           }
       }
   }

   @objc func keyboardWillHide(notification: NSNotification) {
       if self.view.frame.origin.y != 0 {
           self.view.frame.origin.y = 0
       }
   }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return tempArr.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return tempArr[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.RegionTF.text = tempArr[row]
    
    }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {   //delegate method
       textField.resignFirstResponder()
       return true
    }

    @IBAction func LogInBTAction(_ sender: Any) {
       
        if lvm.checkUsersInputs(username: UserNameTF.text ?? "", password: PassWordTF.text ?? "") {
           self.ActIng.startAnimating()
           self.ActIng.isHidden = false
            let loginDic = NSMutableDictionary()
            loginDic.setValue(UserNameTF.text ?? "", forKey: "username")
            loginDic.setValue(PassWordTF.text ?? "", forKey: "password")
            print(loginDic)
            var  jsonData = Data()
            do {
             jsonData = try JSONSerialization.data(withJSONObject: loginDic, options: .prettyPrinted) as Data
               
            } catch {
                print(error.localizedDescription)
            }
         
            WebService().load(resource: Resource<LoginResModel>(url: URL(string: api.loginUrl)!, httpMethod: HttpMethod.post, body:jsonData as Data)){ result in
                switch result {
                case .success(let ARes):
                    print(ARes)
                    self.ActIng.stopAnimating()
                    self.ActIng.isHidden = true
                self.lvm.setup(vm: ARes)
                if(ARes.message == "Successful login." && (UserDefaults.standard.object(forKey: "authentication") != nil)){
                     let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ListVC") as? ListVC
                    self.navigationController?.pushViewController(vc!, animated: true)
                }else{
                    self.popupAlert(title: "Sustainable Certification", message: "Plz try again", actionTitles: ["Option1","Option2"], actions:[{action1 in

                                   },{action2 in

                                   }, nil])
                    }

                case .failure(let error):
                    print(error)
                }
            }

        }else{
            self.popupAlert(title: "Sustainable Certification", message: " Plz Enter correct UserName and Password ", actionTitles: ["Option1","Option2"], actions:[{action1 in

                },{action2 in

                }, nil])
        }

    }
}

extension UITextField {

   func addDoneButtonOnKeyboard() {
       let keyboardToolbar = UIToolbar()
       keyboardToolbar.sizeToFit()
       let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace,
           target: nil, action: nil)
       let doneButton = UIBarButtonItem(barButtonSystemItem: .done,
           target: self, action: #selector(resignFirstResponder))
       keyboardToolbar.items = [flexibleSpace, doneButton]
       self.inputAccessoryView = keyboardToolbar
   }
}
extension UINavigationController {

override open var shouldAutorotate: Bool {
    get {
        if let visibleVC = visibleViewController {
            return visibleVC.shouldAutorotate
        }
        return super.shouldAutorotate
    }
}

override open var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation{
    get {
        if let visibleVC = visibleViewController {
            return visibleVC.preferredInterfaceOrientationForPresentation
        }
        return super.preferredInterfaceOrientationForPresentation
    }
}

override open var supportedInterfaceOrientations: UIInterfaceOrientationMask{
    get {
        if let visibleVC = visibleViewController {
            return visibleVC.supportedInterfaceOrientations
        }
        return super.supportedInterfaceOrientations
    }
}}

