//
//  AuditInfoVC.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 13/02/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit

class AuditInfoVC: UIViewController,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UIGestureRecognizerDelegate {
    
    @IBOutlet weak var DatePicker: UIDatePicker!
    @IBOutlet weak var ActIng: UIActivityIndicatorView!
    @IBOutlet weak var TableView2: UITableView!
    @IBOutlet weak var TableView1: UITableView!
    private var ldvm = ListDetailViewModel()
    var auditID : String?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.interactivePopGestureRecognizer?.delegate = self;
        self.ActIng.transform = CGAffineTransform(scaleX: 1.5, y: 1.5)
        let value = UIInterfaceOrientation.portrait.rawValue
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy/MM/dd"
        var strDate = dateFormatter.string(from: DatePicker.date)
        UIDevice.current.setValue(value, forKey: "orientation")
        // Do any additional setup after loading the view.
        loadData()
        DatePicker = UIDatePicker()
        //dobTF.inputView = picker//Change your textfield name
        DatePicker?.addTarget(self, action: #selector(handleDatePicker), for: .valueChanged)
        DatePicker?.datePickerMode = .date

        //Write toolbar code for done button
        let toolBar = UIToolbar()
        toolBar.barStyle = .default
        toolBar.isTranslucent = true
        let space = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(onClickDoneButton))
        toolBar.setItems([space, doneButton], animated: false)
        toolBar.isUserInteractionEnabled = true
        toolBar.sizeToFit()
        //dobTF.inputAccessoryView = toolBar
        
        
    }
    @objc func handleDatePicker() {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy" //Change your date formate
        let strDate = dateFormatter.string(from: DatePicker!.date)
       // dobTF.text = strDate
    }

    //Toolbar done button function
    @objc func onClickDoneButton() {
        self.view.endEditing(true)
    }
    func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }
    func loadData(){
        ActIng.startAnimating()
        
        let listdetailsInputs = NSMutableDictionary()
        listdetailsInputs.setValue(auditID  , forKey: "audit_id")
        listdetailsInputs.setValue(UserDefaults.standard.object(forKey: "region") as? String, forKey: "region")
        listdetailsInputs.setValue(UserDefaults.standard.object(forKey: "authentication") as? String, forKey: "user_auth_token")
        var  jsonData = Data()
        do {
            jsonData = try JSONSerialization.data(withJSONObject: listdetailsInputs, options: .prettyPrinted) as Data
        } catch {
            print(error.localizedDescription)
        }
        
        WebService().load(resource: Resource<ListDetailsModel>(url: URL(string: api.listdetailUrl)!, httpMethod: HttpMethod.post, body:jsonData as Data)){ result in
            switch result {
            case .success(let ListDetailRes):
                print(ListDetailRes)
                self.ActIng.stopAnimating()
                self.ActIng.isHidden = true
                self.ldvm.setup(vm: ListDetailRes)
                print("sdfsfsf",self.ldvm.AUDIT_FINDINGS ?? "")
//               for fd in self.ldvm.AUDIT_FINDINGS ?? []{
//
//                       }
                
                self.TableView1.reloadData()
                
            case .failure(let error):
                print(error)
            }
        }
    }
//    func calthecount()->Int{
//        var countArr = [Int]()
//        if ((ldvm.AUDIT_RELATED_INFORMATION?.count) != nil) {
//            countArr.append(1)
//        }
//        return countArr.count
//    }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    
    @IBAction func BackBT(_ sender: Any) {
        dismiss(animated: true, completion: nil)
        navigationController?.popViewController(animated: true)
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        print("TextField did end editing method called \(textField.text!) dfsdfdsf \(textField.accessibilityHint ?? "aaa")")
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        return true;
    }
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        
        return true;
    }
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        return true;
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        return true;
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // print("TextField should return method called \(textField.text!) fgdfgfg  \(textField.text!)")
        textField.resignFirstResponder();
        return true;
    }   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if ldvm.audit_id.count >= 1 {
            return 16
        }else{
            return 0
        }
        
        
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cellIdentifier:String = "AudiInfo"
            let cell:AuditInfo? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? AuditInfo
            cell?.TitleLbl.text = "Audit Id:"
            cell?.DesLbl.text = ldvm.audit_id[0]
            if (indexPath.row % 2 == 0) {
                cell?.backgroundColor = UIColor(red: 225/255.0, green: 226/255.0, blue: 228/255.0, alpha: 1.0)
            }else{
                cell?.backgroundColor = UIColor.white
            }
            return cell!
        }else if indexPath.row == 1 {
            let cellIdentifier:String = "AudiInfo"
            let cell:AuditInfo? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? AuditInfo
            cell?.TitleLbl.text = "Account Manager:"
            cell?.DesLbl.text = ldvm.account_manager[0]
            if (indexPath.row % 2 == 0) {
                cell?.backgroundColor = UIColor(red: 225/255.0, green: 226/255.0, blue: 228/255.0, alpha: 1.0)
            }else{
                cell?.backgroundColor = UIColor.white
            }
            return cell!
        }else if indexPath.row == 2 {
            let cellIdentifier:String = "AudInfoDateCell"
            let cell:AudInfoDateCell? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? AudInfoDateCell
            cell?.DateTF.tag = 0
            cell?.TitleLbl.text = "Audit Date:"
            cell?.DateTF.text = ldvm.audit_date[0]
            if (indexPath.row % 2 == 0) {
                cell?.backgroundColor = UIColor(red: 225/255.0, green: 226/255.0, blue: 228/255.0, alpha: 1.0)
            }else{
                cell?.backgroundColor = UIColor.white
            }
            return cell!
        }else if indexPath.row == 3 {
            let cellIdentifier:String = "AudInfoInputCell"
            let cell:AudInfoInputCell? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? AudInfoInputCell
            cell?.TitleLbl.text = "Audit Days:"
            cell?.TF.text = ldvm.audit_days[0]
            if (indexPath.row % 2 == 0) {
                cell?.backgroundColor = UIColor(red: 225/255.0, green: 226/255.0, blue: 228/255.0, alpha: 1.0)
            }else{
                cell?.backgroundColor = UIColor.white
            }
            return cell!
            
        }else if indexPath.row == 4 {
            let cellIdentifier:String = "AudInfoInputCell"
            let cell:AudInfoInputCell? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? AudInfoInputCell
            cell?.TitleLbl.text = "Remote Audit Days:"
            cell?.TF.text = ldvm.remote_audit_days[0]
            if (indexPath.row % 2 == 0) {
                cell?.backgroundColor = UIColor(red: 225/255.0, green: 226/255.0, blue: 228/255.0, alpha: 1.0)
            }else{
                cell?.backgroundColor = UIColor.white
            }
            return cell!
            
        }else if indexPath.row == 5 {
            let cellIdentifier:String = "AudInfoDInputCell"
            let cell:AudInfoDInputCell? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? AudInfoDInputCell
            cell?.TitleLbl.text = "LA Status:"
            cell?.DTF.text = ldvm.LA_Status[0]
            if (indexPath.row % 2 == 0) {
                cell?.backgroundColor = UIColor(red: 225/255.0, green: 226/255.0, blue: 228/255.0, alpha: 1.0)
            }else{
                cell?.backgroundColor = UIColor.white
            }
            return cell!
        }else if indexPath.row == 6 {
            let cellIdentifier:String = "AudInfoDInputCell"
            let cell:AudInfoDInputCell? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? AudInfoDInputCell
            cell?.TitleLbl.text = "Recommendation:"
            cell?.DTF.text = ldvm.Recomm_endation[0]
            if (indexPath.row % 2 == 0) {
                cell?.backgroundColor = UIColor(red: 225/255.0, green: 226/255.0, blue: 228/255.0, alpha: 1.0)
            }else{
                cell?.backgroundColor = UIColor.white
            }
            return cell!
        }else if(indexPath.row == 7){
            let cellIdentifier:String = "TextViewInputsTVC"
            let cell:TextViewInputsTVC? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? TextViewInputsTVC
            cell?.TitleLbl.text = "Notes to Aditor:"
            cell?.TextInputs.text = " "
                    return cell!
               }
            else if(indexPath.row == 8){
                       let cellIdentifier:String = "TextViewInputsTVC"
                        let cell:TextViewInputsTVC? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? TextViewInputsTVC
            
                cell?.TitleLbl.text = "Special request to Lead Auditor:"
                cell?.TextInputs.text = " "
            
                        return cell!
                   }
            else if(indexPath.row == 9){
                       let cellIdentifier:String = "AuditInfoDetail"
                                   let cell:AuditInfoDetail? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? AuditInfoDetail
                       
                                   cell?.TitleLbl.text = "Anzsic code"
                                   cell?.DesLbl.text = "ANZISC-6932"
                                   return cell!
                   }
            else if(indexPath.row == 10){
                let cellIdentifier:String = "AuditInfoDetail"
                            let cell:AuditInfoDetail? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? AuditInfoDetail
                
                            cell?.TitleLbl.text = "Scope"
                            cell?.DesLbl.text = "Not known"
                            return cell!
            }
           
        else if(indexPath.row == 11){
           let cellIdentifier:String = "TextViewInputsTVC"
                                  let cell:TextViewInputsTVC? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? TextViewInputsTVC
                      
                          cell?.TitleLbl.text = "LEGAL_AND_LEGISLATIVE_REQUIREMENTS"
                          cell?.TextInputs.text = " "
                      
                                  return cell!
        }
            else if(indexPath.row == 12){
                           let cellIdentifier:String = "AuditInfoDetail"
                                       let cell:AuditInfoDetail? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? AuditInfoDetail
                           
                                       cell?.TitleLbl.text = "Scope"
                                       cell?.DesLbl.text = "Not known"
                                       return cell!
                       }
            else if(indexPath.row == 13){
                           let cellIdentifier:String = "AuditInfoDetail"
                                       let cell:AuditInfoDetail? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? AuditInfoDetail
                           
                                       cell?.TitleLbl.text = "SUMMARY_OF_FINDINGS"
                                       cell?.DesLbl.text = "Not known"
                                       return cell!
                       }
            else if(indexPath.row == 14){
                           let cellIdentifier:String = "AuditInfoDetail"
                                       let cell:AuditInfoDetail? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? AuditInfoDetail
                           
                                       cell?.TitleLbl.text = "OPPORTUNITIES_FOR_IMPROVEMENT"
                                       cell?.DesLbl.text = "Not known"
                                       return cell!
                       }
        else{
//            let cellIdentifier:String = "AudiInfo"
//            let cell:AuditInfo? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? AuditInfo
//            cell?.TitleLbl.text = "Audit Id:"
//            cell?.DesLbl.text = ldvm.audit_id[0]
//            if (indexPath.row % 2 == 0) {
//                cell?.backgroundColor = UIColor.lightGray
//            }else{
//                cell?.backgroundColor = UIColor.white
//            }
//            return cell!
            let cellIdentifier:String = "TFindingTVCell"
                              let cell:TFindingTVCell? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? TFindingTVCell
                  
                              return cell!
        }
        
        
        //        }else if(indexPath.row == 5){
        //            let cellIdentifier:String = "AudInfoDateCell"
        //            let cell:AudInfoDateCell? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? AudInfoDateCell
        //            cell?.DateTF.tag = 0
        //            cell?.ConfirDDown.tag = 1
        //            cell?.ConfirDDown.accessibilityHint = "apple"
        //
        //            if (indexPath.row % 2 == 0) {
        //                cell?.backgroundColor = UIColor.white
        //            }else{
        //                cell?.backgroundColor = UIColor.lightGray
        //            }
        //
        //
        //            return cell!
        //        }else if(indexPath.row == 6){
        //            let cellIdentifier:String = "AudInfoDInputCell"
        //            let cell:AudInfoDInputCell? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? AudInfoDInputCell
        //            cell?.DTF.tag = 2
        //            if (indexPath.row % 2 == 0) {
        //                cell?.backgroundColor = UIColor.white
        //            }else{
        //                cell?.backgroundColor = UIColor.lightGray
        //            }
        //            return cell!
        //        }
        //        else if(indexPath.row ==  9){
        //            let cellIdentifier:String = "TFindingTVCell"
        //            let cell:TFindingTVCell? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? TFindingTVCell
        //
        //            return cell!
        //        }
        //        else if(indexPath.row >= 10){
        //           let cellIdentifier:String = "TextViewInputsTVC"
        //            let cell:TextViewInputsTVC? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? TextViewInputsTVC
        //
        //            cell?.TitleLbl.text = "title"
        //            cell?.TextInputs.text = "hkjgkgh hvhjvhvh hvhvhvhmv jhvhjvhvhvyvuyvu jjghvjhvjhv"
        //
        //            return cell!
        //        }
        //        else{
        //            let cellIdentifier:String = "AuditInfoDetail"
        //            let cell:AuditInfoDetail? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? AuditInfoDetail
        //
        //            cell?.TitleLbl.text = "wdwedwed"
        //            cell?.DesLbl.text = "sdfasfasf sfjkas bjfkba skhjf kjbsjx kdbkjasbdkjasd"
        //            return cell!
        //        }
        
    }
//        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//            if indexPath.row == 8{
//                 return 113
//            }else{
//                return 50
//            }
//           
//        }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 15{
            let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "PageViewPV") as? PageViewPV
            print("apple",self.ldvm.AUDIT_FINDINGS)
//                   vc?.Name=ldvm.Name
//                   vc?.position=ldvm.position
//                   vc?.entry_image=ldvm.entry_image
//                   vc?.exit_image=ldvm.entry_image
//                   vc?.reason_if_not=ldvm.reason_if_not
                   self.navigationController?.pushViewController(vc!, animated: true)
        }
    }
    @IBAction func ViewAttendanceBT(_ sender: Any) {
        
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "AttendanceListVC") as? AttendanceListVC
        vc?.Name=ldvm.Name
        vc?.position=ldvm.position
        vc?.entry_image=ldvm.entry_image
        vc?.exit_image=ldvm.entry_image
        vc?.reason_if_not=ldvm.reason_if_not
        self.navigationController?.pushViewController(vc!, animated: true)
        
    }
    func changeToTitle(title:String) -> String {
        
        let editedText = title.uppercased().replacingOccurrences(of: "_", with: " ")
        return editedText
    }
    @IBAction func DatepickerAction(_ sender: Any) {
//        let dateFormatter = DateFormatter()
//
//        dateFormatter.dateStyle = DateFormatter.Style.short
//        dateFormatter.timeStyle = DateFormatter.Style.short
//
//        let strDate = dateFormatter.string(from: DatePicker.date)
//       // dateLabel.text = strDate
       }
    
}
//extension AuditInfoVC:UIGestureRecognizerDelegate {
//
//}
