//
//  AttendanceListVC.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 17/02/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit

class AttendanceListVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
   //var dataListDic = NSDictionary()
    var Name : [String]?
    var position : [String]?
    var entry_image : [String]?
    var exit_image : [String]?
    var reason_if_not : [String]?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func BackBT(_ sender: Any) {
        dismiss(animated: true, completion: nil)
               navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Name?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier:String = "AttendanceTVCell"
        let cell:AttendanceTVCell? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? AttendanceTVCell
        cell?.Name.text = Name?[indexPath.row]
        cell?.Position.text = position?[indexPath.row]
        cell?.StartBT.addTarget(self, action: #selector(StartBTAction(sender:)), for: .touchUpInside)
        cell?.StartBT.tag = indexPath.row
        cell?.ExitBT.addTarget(self, action: #selector(ExitBTAction(sender:)), for: .touchUpInside)
        cell?.ExitBT.tag = indexPath.row
        return cell!
    }
    @objc func StartBTAction(sender: UIButton){
        let buttonTag = sender.tag
        print(buttonTag)
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "AddAttendanceVC") as? AddAttendanceVC
        vc?.positionStr = position?[sender.tag] ?? ""
        self.navigationController?.pushViewController(vc!, animated: true)
    }
    @objc func ExitBTAction(sender: UIButton){
        let buttonTag = sender.tag
        print(buttonTag)
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "AddAttendanceVC") as? AddAttendanceVC
         vc?.positionStr = position?[sender.tag] ?? ""
        self.navigationController?.pushViewController(vc!, animated: true)
        
    }

}
