//
//  ListVC.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 25/01/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit
import AVFoundation
class ListVC: UIViewController,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate {
    
    
    @IBOutlet weak var CloseBT: UIButton!
    @IBOutlet weak var SearchBT: UIButton!
    @IBOutlet weak var SearchTF: UITextField!
    @IBOutlet weak var AlphaTV: UITableView!
    @IBOutlet weak var ActIng: UIActivityIndicatorView!
    private var lvm = ListViewModel()
    
    @IBOutlet weak var TV: UITableView!
    var offset=Int()
    var PageCount=Int()
    var RecordCount=Int()
    var TotalCount = Int()
    var alphaStr : String?
    var RespArr = NSMutableArray()
    var alphaArr : [String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        alphaArr = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
        self.ActIng.isHidden = true
        self.ActIng.transform = CGAffineTransform(scaleX: 1.5, y: 1.5)
        PageCount = 50
        offset = 0
        loadData(offset: offset, pagesize: PageCount, searchkey: "", alphabet_sorting: "")
        let value = UIInterfaceOrientation.portrait.rawValue
        UIDevice.current.setValue(value, forKey: "orientation")
        
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if(textField == self.SearchTF){
            self.SearchBT.isHidden = true
            self.CloseBT.isHidden = false
        }
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
       if (textField.text?.count == 0) {
           self.CloseBT.isHidden = true
           self.SearchBT.isHidden = false
       }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        lvm.removeAll()
        textField.resignFirstResponder()
        
        if (textField.text?.count == 0) {
            self.CloseBT.isHidden = true
            self.SearchBT.isHidden = false
        }
        loadData(offset: offset, pagesize: PageCount, searchkey: self.SearchTF.text ?? "", alphabet_sorting: "")
        return true
        
    }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.portrait
    }
    func loadData(offset:Int,pagesize:Int,searchkey:String,alphabet_sorting:String){
        self.TV.isScrollEnabled = false
        self.ActIng.startAnimating()
        self.ActIng.isHidden = false
        let ListInputs = NSMutableDictionary()
        ListInputs.setValue(UserDefaults.standard.object(forKey: "user_id") as? String, forKey: "user_id")
        ListInputs.setValue(UserDefaults.standard.object(forKey: "region") as? String, forKey: "region")
        ListInputs.setValue(UserDefaults.standard.object(forKey: "authentication") as? String, forKey: "user_auth_token")
        ListInputs.setValue(String(offset), forKey: "offset")
        ListInputs.setValue(String(pagesize), forKey: "pagesize")
        ListInputs.setValue(searchkey, forKey: "searchkey")
        ListInputs.setValue(alphabet_sorting, forKey: "alphabet_sorting")
        
        
        print(ListInputs)
        var  jsonData = Data()
        do {
            jsonData = try JSONSerialization.data(withJSONObject: ListInputs, options: .prettyPrinted) as Data
            
        } catch {
            print(error.localizedDescription)
        }
        WebService().load(resource: Resource<ListModel>(url: URL(string: api.listUrl)!, httpMethod: HttpMethod.post, body:jsonData as Data)){ result in
            switch result {
            case .success(let ListRes):
                self.lvm.setup(vm: ListRes)
                print(self.lvm.audit_dateArr)
                print("TotalCount",self.TotalCount)
                self.TotalCount = self.lvm.TOTAL_RECORDS ?? 0
                self.TV.isScrollEnabled = true
                
                self.TV.reloadData()
                self.ActIng.stopAnimating()
                self.ActIng.isHidden = true
            case .failure(let error):
                print(error)
            }
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (tableView == self.AlphaTV) {
            return  alphaArr.count
        }else{
            return lvm.getNumberOfRowsInSection()
        }
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if (tableView == self.AlphaTV) {
            let cellIdentifier:String = "AlphaTVCell"
            let cell:AlphaTVCell? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? AlphaTVCell
            cell?.TitleLbl.text = alphaArr[indexPath.row]
            return cell!
        }else{
            let cellIdentifier:String = "ListCell"
            let cell:ListCell? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? ListCell
            cell?.TitleLbl.text = "Title:\(lvm.organisationArr[indexPath.row])"
            cell?.AuditID.text = "Audit ID:\(lvm.audit_idArr[indexPath.row])"
            if(lvm.AM_StatusArr[indexPath.row]=="Open"){
                cell?.AMSImg.image = UIImage(named: "open.png")
            }else{
                cell?.AMSImg.image = UIImage(named: "close.png")
            }
            cell?.AMSLbl.text = "LA State:"
            if(lvm.LA_StatusArr[indexPath.row]=="Open"){
                cell?.LASImg.image = UIImage(named: "open.png")
                
            }else{
                cell?.LASImg.image = UIImage(named: "close.png")
            }
            cell?.LASLbl.text = "AM State:"
            cell?.TypeLbl.text = "Type:\(lvm.audit_typeArr[indexPath.row])"
            cell?.DateLbl.text = "Date:\(lvm.audit_dateArr[indexPath.row])"
            cell?.OrgLbl.text = "Organisation:\(lvm.standard_titleArr[indexPath.row])"
            return cell!
        }
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (tableView == self.AlphaTV) {
             lvm.removeAll()
            self.showToast(message: alphaArr[indexPath.row])

            //showToast(controller: self, message : alphaArr[indexPath.row], seconds: 2.0)
            let generator = UIImpactFeedbackGenerator(style: .heavy)
            generator.impactOccurred()
            self.SearchTF.text = alphaArr[indexPath.row]
            self.CloseBT.isHidden = false
            self.SearchBT.isHidden = true
            alphaStr = String(indexPath.row)
            loadData(offset: offset, pagesize: PageCount, searchkey:"", alphabet_sorting: String(indexPath.row))

        }else{
            let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "AuditInfoVC") as? AuditInfoVC
            vc?.auditID = lvm.audit_idArr[indexPath.row]
            self.navigationController?.pushViewController(vc!, animated: true)
        }
        
    }
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        print("tot",TotalCount)
        print("so far count",lvm.audit_idArr.count)
        var currentOffset = NSInteger()
        var maximumOffset = NSInteger()
        currentOffset = NSInteger(scrollView.contentOffset.y);
        maximumOffset = NSInteger(scrollView.contentSize.height-scrollView.frame.size.height)
        let value = maximumOffset - currentOffset
        if(value <= 0 ){
            self.TV.isScrollEnabled = false
            if(lvm.audit_idArr.count <= TotalCount){
                if(lvm.Record_Count==PageCount){
                    offset = offset+PageCount
                }else{
                    // offset = offset+lvm.getNumberOfRowsInSection()
                    offset = offset+lvm.Record_Count
                }
                // load function
                if(offset == TotalCount||offset >= TotalCount){
                    PageCount = TotalCount-lvm.audit_idArr.count
                }
                if(TotalCount <= lvm.audit_idArr.count || TotalCount == lvm.audit_idArr.count){
                    self.TV.isScrollEnabled = true
                }else{
                    loadData(offset: offset, pagesize: PageCount, searchkey:"", alphabet_sorting:alphaStr ?? "")
                }
                
            }else{
                
            }
        }
    }
    @IBAction func CloseBT(_ sender: Any) {
        lvm.removeAll()
        alphaStr = ""
        self.SearchTF.resignFirstResponder()
        self.SearchTF.text = ""
        self.CloseBT.isHidden = true
        self.SearchBT.isHidden = false
        offset = 0
        PageCount = 50
        loadData(offset: offset, pagesize: PageCount, searchkey:"", alphabet_sorting: "")
        
    }
    @IBAction func SearchBT(_ sender: Any) {
         self.SearchTF.becomeFirstResponder()
    }
    func showToast(controller: UIViewController, message : String, seconds: Double) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.view.backgroundColor = UIColor.black
        alert.view.alpha = 0.6
        alert.view.layer.cornerRadius = 15

        controller.present(alert, animated: true)

        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + seconds) {
            alert.dismiss(animated: true)
        }
    }
     func showToast(message : String) {

         let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/2 - 75, y: self.view.frame.size.height-100, width: 150, height: 35))
         toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
         toastLabel.textColor = UIColor.white
         toastLabel.textAlignment = .center;
         toastLabel.font = UIFont(name: "Montserrat-Light", size: 12.0)
         toastLabel.text = message
         toastLabel.alpha = 1.0
         toastLabel.layer.cornerRadius = 10;
         toastLabel.clipsToBounds  =  true
         self.view.addSubview(toastLabel)
         UIView.animate(withDuration: 4.0, delay: 0.1, options: .curveEaseOut, animations: {
             toastLabel.alpha = 0.0
         }, completion: {(isCompleted) in
             toastLabel.removeFromSuperview()
         })
     }
    

}
extension UIDevice {
    static func vibrate() {
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)
    }
}
