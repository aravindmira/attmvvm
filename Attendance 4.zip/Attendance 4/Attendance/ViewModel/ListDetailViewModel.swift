//
//  ListDetailViewModel.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 26/02/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import Foundation
struct ListDetailViewModel {
    var AUDIT_RELATED_INFORMATION : [AUDIT_RELATED_INFORMATION]?
    var NOTES_TO_AUDITOR : [NOTES_TO_AUDITOR]?
    var SPECIAL_REQUESTS_TO_LEAD_AUDITOR : [SPECIAL_REQUESTS_TO_LEAD_AUDITOR]?
    var ANZSIC_CODE : [ANZSIC_CODE]?
    var SCOPE : [SCOPE]?
    var RISK : [RISK]?
    var LEGAL_AND_LEGISLATIVE_REQUIREMENTS : [LEGAL_AND_LEGISLATIVE_REQUIREMENTS]?
    var SUMMARY_OF_FINDINGS : [SUMMARY_OF_FINDINGS]?
    var STRENGTHS : [STRENGTHS]?
    var OPPORTUNITIES_FOR_IMPROVEMENT : [OPPORTUNITIES_FOR_IMPROVEMENT]?
   var AUDIT_FINDINGS : [AUDIT_FINDINGS]?
    
    var audit_id = [String]()
    var account_manager = [String]()
    var audit_date = [String]()
    var audit_days = [String]()
    var remote_audit_days = [String]()
    var LA_Status = [String]()
    var Recomm_endation = [String]()
    var Name = [String]()
    var position = [String]()
    var entry_image = [String]()
    var exit_image = [String]()
    var reason_if_not = [String]()
    
    mutating func setup(vm :ListDetailsModel){
        AUDIT_RELATED_INFORMATION = vm.AUDIT_RELATED_INFORMATION
        NOTES_TO_AUDITOR = vm.NOTES_TO_AUDITOR
        ANZSIC_CODE = vm.ANZSIC_CODE
        SCOPE = vm.SCOPE
        RISK = vm.RISK
        LEGAL_AND_LEGISLATIVE_REQUIREMENTS = vm.LEGAL_AND_LEGISLATIVE_REQUIREMENTS
        SUMMARY_OF_FINDINGS = vm.SUMMARY_OF_FINDINGS
        STRENGTHS = vm.STRENGTHS
        OPPORTUNITIES_FOR_IMPROVEMENT = vm.OPPORTUNITIES_FOR_IMPROVEMENT
        SPECIAL_REQUESTS_TO_LEAD_AUDITOR = vm.SPECIAL_REQUESTS_TO_LEAD_AUDITOR
        AUDIT_FINDINGS = vm.AUDIT_FINDINGS
        
        Name = vm.AUDIT_ATTENDANCE.Name ?? []
        position = vm.AUDIT_ATTENDANCE.position ?? []
        entry_image = vm.AUDIT_ATTENDANCE.entry_image ?? []
        exit_image = vm.AUDIT_ATTENDANCE.exit_image ?? []
        reason_if_not = vm.AUDIT_ATTENDANCE.reason_if_not ?? []
        
        
        for ARI in AUDIT_RELATED_INFORMATION ?? [] {
            audit_id.append(ARI.audit_id ?? "")
            account_manager.append(ARI.account_manager ?? "")
            audit_date.append(ARI.audit_date ?? "")
            audit_days.append(ARI.audit_days ?? "")
            remote_audit_days.append(ARI.remote_audit_days ?? "")
            LA_Status.append(ARI.LA_Status ?? "")
            Recomm_endation.append(ARI.Recomm_endation ?? "")
        }
        
//        for fd in AUDIT_FINDINGS ?? []{
//            fd.FINDINGS
//            
//        }
        
    }
    func calthecount()->Int{
        var countArr = [Int]()
        if ((AUDIT_RELATED_INFORMATION?.count) != nil) {
            countArr.append(1)
        }
         if ((NOTES_TO_AUDITOR?.count) != nil) {
            countArr.append(1)
        }
         if ((SPECIAL_REQUESTS_TO_LEAD_AUDITOR?.count) != nil) {
            countArr.append(1)
        }
         if ((ANZSIC_CODE?.count) != nil) {
            countArr.append(1)
        }
         if ((SCOPE?.count) != nil) {
            countArr.append(1)
        }
         if ((RISK?.count) != nil) {
            countArr.append(1)
        }
         if ((LEGAL_AND_LEGISLATIVE_REQUIREMENTS?.count) != nil) {
            countArr.append(1)
        }
         if ((SUMMARY_OF_FINDINGS?.count) != nil) {
            countArr.append(1)
        }
         if ((STRENGTHS?.count) != nil) {
            countArr.append(1)
        }
         if ((SPECIAL_REQUESTS_TO_LEAD_AUDITOR?.count) != nil) {
            countArr.append(1)
        }
        return countArr.count
    }
    
}
