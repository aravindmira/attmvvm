//
//  ListViewModel.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 25/01/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import Foundation
//struct ListViewModel {
//    var audit_reports : [ListModel]?
//      var AM_Status = [String]()
//      var LA_Status = [String]()
//      var Recomm_endation = [String]()
//      var Response_date = [String]()
//      var audit_date = [String]()
//      var audit_id = [String]()
//      var audit_plan = [String]()
//      var audit_type = [String]()
//      var organisation = [String]()
//      var standard_title = [String]()
//    mutating func setup(vm:[ListModel]){
//
//        audit_reports = vm
//        for ar in audit_reports ?? []{
//
//            AM_Status.append(ar.AM_Status ?? "")
//            LA_Status.append(ar.LA_Status ?? "")
//            Recomm_endation.append(ar.Recomm_endation ?? "")
//            Response_date.append(ar.Response_date ?? "")
//            audit_date.append(ar.audit_date ?? "")
//            audit_id.append(ar.audit_id ?? "")
//            audit_plan.append(ar.audit_plan ?? "")
//            audit_type.append(ar.audit_type ?? "")
//            organisation.append(ar.organisation ?? "")
//            standard_title.append(ar.standard_title ?? "")
//            print(ar.audit_id)
//        }
//    }
//    func getNumberOfRowsInSection() -> Int{
//
//        return audit_reports?.count ?? 0
//
//    }
//    func dataAtIndex(at index: Int) -> ListModel{
//
//        return (audit_reports?[index])!
//    }
//
//}
struct ListViewModel{
    var Audit_list : [AUDIT_LIST]?
    var TOTAL_RECORDS : Int?
    var AM_StatusArr = [String]()
    var LA_StatusArr = [String]()
    var Recomm_endationArr = [String]()
    var Response_dateArr = [String]()
    var audit_dateArr = [String]()
    var audit_idArr = [String]()
    var audit_planArr = [String]()
    var audit_typeArr = [String]()
    var organisationArr = [String]()
    var standard_titleArr = [String]()
    var Record_Count = Int()
    mutating func setup(vm:ListModel){
        TOTAL_RECORDS = vm.TOTAL_RECORDS
        Audit_list = vm.AUDIT_LIST
        Record_Count = Audit_list?.count ?? 0
        print("Record count is \(Audit_list?.count)")
        for al in  Audit_list ?? []{
            AM_StatusArr.append(al.AM_Status ?? "")
            LA_StatusArr.append(al.LA_Status ?? "")
            Recomm_endationArr.append(al.Recomm_endation ?? "")
            audit_dateArr.append(al.audit_date ?? "")
            audit_idArr.append(al.audit_id ?? "")
            audit_planArr.append(al.audit_plan ?? "")
            audit_typeArr.append(al.audit_type ?? "")
            organisationArr.append(al.organisation ?? "")
            standard_titleArr.append(al.standard_title ?? "")
        }
    }
    func getNumberOfRowsInSection() -> Int{
        
        return audit_idArr.count ?? 0
        
    }
    func dataAtIndex(at index: Int) -> AUDIT_LIST{
        
        return (Audit_list?[index])!
    }
    mutating func removeAll(){
        AM_StatusArr.removeAll()
        LA_StatusArr.removeAll()
        Recomm_endationArr.removeAll()
        Response_dateArr.removeAll()
        audit_dateArr.removeAll()
        audit_idArr.removeAll()
        audit_planArr.removeAll()
        audit_typeArr.removeAll()
        organisationArr.removeAll()
        standard_titleArr.removeAll()
    }
}

