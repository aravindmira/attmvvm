//
//  LoginViewModel.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 23/01/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import Foundation
struct LoginViewModel {
   var user_group_id : String?
   var user_id : String?
   var user_type : String?
   var user_name : String?
   var region :String?
   var message :String?
   var authentication :String?
    
    func checkUsersInputs (username:String,password:String) ->Bool{
        if (username.count >= 2 && password.count >= 2){
            return true
        }else{
            return false
        }
    }
    mutating func setup(vm :LoginResModel){
        user_group_id = vm.user_group_id
        user_id = vm.user_id
        user_name = vm.user_name
        user_type = vm.user_type
        region = vm.region
        message = vm.message
        authentication = vm.authentication
        if(message == "Successful login."){
            UserDefaults.standard.set(user_id, forKey: "user_id")
            UserDefaults.standard.set(authentication, forKey: "authentication")
            UserDefaults.standard.set(region, forKey: "region")
        }
    }
}
