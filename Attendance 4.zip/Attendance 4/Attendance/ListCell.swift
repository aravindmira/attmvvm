//
//  ListCell.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 25/01/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit

class ListCell: UITableViewCell {

    @IBOutlet weak var AuditID: UILabel!
    @IBOutlet weak var AMSImg: UIImageView!
    @IBOutlet weak var AMSLbl: UILabel!
    @IBOutlet weak var LASImg: UIImageView!
    @IBOutlet weak var LASLbl: UILabel!
    @IBOutlet weak var TypeLbl: UILabel!
    @IBOutlet weak var DateLbl: UILabel!
    @IBOutlet weak var OrgLbl: UILabel!
    @IBOutlet weak var TitleLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
