//
//  PagScrVc.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 21/02/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit

class PagScrVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var pageIndex: Int = 0
    var strTitle: String!
    var strPhotoName: String!
    var TotalPage = Int()
    var FindingsArr = [String]()
    var FindingsOddArr = [String]()
    var FindingsEvenArr = [String]()
    struct options {
        var name = String()
        var flag = Int()
    }
    var dataArray = [options]()
    @IBOutlet weak var InputTextView: UITextView!
    @IBOutlet weak var SpellSwState: UISwitch!
    
    @IBOutlet weak var TableView: UITableView!
    
    
    @IBOutlet weak var PGC: UIPageControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SpellSwState.setOn(false, animated:true)
        PGC.numberOfPages = TotalPage
        PGC.currentPage = pageIndex
        FindingsArr=["Compliant: Meets Requirements of the standard","Minor Non Conformity ","Major Non Conformity","Compliant:Meets requirements of the standard with observation noted","Not assessed this Audit"]
        for i in 0..<FindingsArr.count{
            dataArray.append(options(name: FindingsArr[i], flag: 0))
        }
        print("FindingsOddArr \(FindingsOddArr)")
         print("FindingsEvenArr \(FindingsEvenArr)")
    }
    override func viewDidAppear(_ animated: Bool) {
        
    }
    @IBAction func NextBT(_ sender: Any) {
        NotificationCenter.default.post(name: .PVMoveNext, object: "myObject")
    }
    @IBAction func PreBT(_ sender: Any) {
        NotificationCenter.default.post(name: .PVMoveBack, object: "myObject")
    }
    @IBAction func SpellAction(_ sender: Any) {
        if SpellSwState.isOn {
            
            print("The Switch is on")
            InputTextView.autocorrectionType = .yes
            if InputTextView.autocorrectionType == .yes {
                print("auto correction is on")
            }else{
                print("auto correction is off")
            }
        } else {
            print("The Switch is off")
            InputTextView.autocorrectionType = .no
            if InputTextView.autocorrectionType == .yes {
                print("auto correction is on")
            }else{
                print("auto correction is off")
            }
        }
        
    }
    @IBAction func BackBT(_ sender: Any) {
        dismiss(animated: true, completion: nil)
        navigationController?.popViewController(animated: true)
    }
    //Table view delegate
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return FindingsArr.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 30
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if(dataArray[indexPath.row].flag == 0){
            dataArray[indexPath.row].flag = 1
        }else{
            dataArray[indexPath.row].flag = 0
        }
        self.TableView.reloadData()
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier:String = "RadioInputsCell"
        let cell:RadioInputsCell? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? RadioInputsCell
        cell?.TitleLbl.text = dataArray[indexPath.row].name
        if(dataArray[indexPath.row].flag == 0){
           cell?.RadioImg.image = UIImage(named: "radioOff.png")
        }else{
           cell?.RadioImg.image = UIImage(named: "radioOn.png")
        }
      

        
        
//        cell?.oddBT.setTitle(FindingsOddArr[indexPath.row],for: .normal)
//        cell?.evenBT.setTitle(FindingsEvenArr[indexPath.row],for: .normal)
////        if (FindingsEvenArr.count <= indexPath.row){
////              cell?.evenBT.setTitle(FindingsEvenArr[indexPath.row],for: .normal)
////        }
//
//
//
//        cell?.oddBT.addTarget(self, action: #selector(oddBT(sender:)), for: .touchUpInside)
//        cell?.oddBT.accessibilityHint = ""
//        cell?.oddBT.addRightImage(name:"radioOff.png", offset: 0)
//
//        cell?.evenBT.addTarget(self, action: #selector(evenBT(sender:)), for: .touchUpInside)
//        cell?.evenBT.accessibilityHint = ""
//        cell?.evenBT.addRightImage(name:"radioOff.png", offset: 0)
//
        return cell!
    }
    @objc func oddBT(sender: UIButton){ //let buttonTag = sender.tag
        print( sender.accessibilityHint ?? "aaa")
        
    }
    @objc func evenBT(sender: UIButton){ //let buttonTag = sender.tag
        print( sender.accessibilityHint ?? "aaa")
        
    }
    
    
}
