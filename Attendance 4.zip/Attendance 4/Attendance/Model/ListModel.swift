//
//  ListModel.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 25/01/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import Foundation

struct ListModel : Codable{
    let AUDIT_LIST : [AUDIT_LIST]?
    let TOTAL_RECORDS : Int?
}
struct AUDIT_LIST : Codable{
    let AM_Status : String?
    let LA_Status : String?
    let Recomm_endation : String?
    let Response_date : String?
    let audit_date : String?
    let audit_id : String?
    let audit_plan : String?
    let audit_type : String?
    let organisation : String?
    let standard_title : String?
}

