//
//  ListDetailsModel.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 26/02/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import Foundation
struct ListDetailsModel : Codable{
    var AUDIT_RELATED_INFORMATION : [AUDIT_RELATED_INFORMATION]
    var AUDIT_ATTENDANCE : AUDIT_ATTENDANCE
    var NOTES_TO_AUDITOR : [NOTES_TO_AUDITOR]?
    var SPECIAL_REQUESTS_TO_LEAD_AUDITOR : [SPECIAL_REQUESTS_TO_LEAD_AUDITOR]?
    var ANZSIC_CODE : [ANZSIC_CODE]?
    var SCOPE : [SCOPE]?
    var RISK : [RISK]?
    var LEGAL_AND_LEGISLATIVE_REQUIREMENTS : [LEGAL_AND_LEGISLATIVE_REQUIREMENTS]?
    var SUMMARY_OF_FINDINGS : [SUMMARY_OF_FINDINGS]?
    var STRENGTHS : [STRENGTHS]?
    var OPPORTUNITIES_FOR_IMPROVEMENT : [OPPORTUNITIES_FOR_IMPROVEMENT]?
    var AUDIT_FINDINGS : [AUDIT_FINDINGS]?
}
struct AUDIT_RELATED_INFORMATION : Codable {
   var audit_id : String?
   var account_manager : String?
   var audit_date : String?
   var audit_days : String?
   var remote_audit_days : String?
   var LA_Status : String?
   var Recomm_endation : String?
}
struct AUDIT_ATTENDANCE : Codable{
    var Name : [String]?
    var position : [String]?
    var entry_image : [String]?
    var exit_image : [String]?
    var reason_if_not : [String]?
}



struct NOTES_TO_AUDITOR : Codable {
    var auditor_notes : String?
}
struct SPECIAL_REQUESTS_TO_LEAD_AUDITOR : Codable {
    var special_request_la : String?
}
struct ANZSIC_CODE : Codable {
    var ANZSIC : String?
}
struct SCOPE : Codable {
    var SCOPE : String?
}
struct RISK : Codable {
    var risk_level : String?
}
struct LEGAL_AND_LEGISLATIVE_REQUIREMENTS : Codable {
    var legal_legis_req : String?
}
struct SUMMARY_OF_FINDINGS : Codable {
    var comments : String?
}
struct STRENGTHS : Codable {
    var strengths : String?
}
struct OPPORTUNITIES_FOR_IMPROVEMENT : Codable {
    var weaknesses : String?
}
struct AUDIT_FINDINGS : Codable{
    var FINDINGS: Dictionary = [Int: String]()
    var audit_title_id : String?
    var clause_number : String?
    var mandatory : String?
    var result : String?
    var show_auditreport : String?
    var show_finding : String?
    var standard_rating : String?
    var sub_title : String?
    var title : String?
    var titleonly : String?
    var titlereq :String?
}

