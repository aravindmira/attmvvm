//
//  LoginModel.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 23/01/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import Foundation
struct LoginResModel: Codable{

 let user_group_id : String?
 let user_id : String?
 let user_type : String?
 let user_name : String?
 let region :String?
 let message :String?
 let authentication :String?

}

//"user_id": "11223",
//"user_type": "lead_auditor",
//"user_name": "erica",
//"status": "Active",
//"region": "AU",
//"message": "Successful login.",
//"authentication": "3f58df89d950d208"
