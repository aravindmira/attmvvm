//
//  Contant.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 23/01/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import Foundation
let baseUrl = "http://stage.sustainablecertification.net.au/ver3/api/"
//let baseUrl = "https://www.bossint.com.au/aescfresh/mobileappapi/"
struct api{
  static  let loginUrl = "\(baseUrl)login_api.php?"
  static  let listUrl = "\(baseUrl)audit_reports_api.php"
  static  let listdetailUrl = "\(baseUrl)audit_details_api.php"
}
