//
//  GradientBTCust.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 10/02/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit

class GradientBTCust: UIButton {

    override func layoutSubviews() {

        let layer : CAGradientLayer = CAGradientLayer()
        layer.frame.size = self.frame.size
        layer.frame.origin = CGPoint(x: 0, y: 0)

        //   layer.cornerRadius = CGFloat(frame.width / 20)
        let color0 = UIColor(red:255/255, green:122/255, blue:0/255, alpha:1.0).cgColor
        let color1 = UIColor(red:255/255, green:176/255, blue: 0/255, alpha:1.0).cgColor
        let color2 = UIColor(red:250/255, green:98/255, blue: 44/255, alpha:1.0).cgColor
        layer.locations = [0.5, 1.0]
        layer.startPoint = CGPoint(x: 0.0, y: 0.5)
        layer.endPoint = CGPoint(x: 0.5, y: 0.5)
        layer.colors = [color2,color0,color1]

        self.layer.insertSublayer(layer, at: 0)
    }

}
