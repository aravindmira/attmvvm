//
//  RegionTFCust.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 10/02/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit

class RegionTFCust: UITextField {
    func setup() {

        self.rightViewMode = UITextField.ViewMode.always
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 10, height: 20))
        let image = UIImage(named: "Down.png")
        imageView.image = image
        self.rightView = imageView
         

    }

   override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setup()
    }
    
//          super.init(frame: frame)
//                 setup()
//
//    let border = CALayer()
//                   let width = CGFloat(1.0)
//                   border.borderColor = UIColor.blue.cgColor
//                   border.frame = CGRect(x: 0, y: frame.size.height - width, width: frame.size.width, height: frame.size.height)
//
//                   border.borderWidth = width
//                   layer.addSublayer(border)
//                   layer.masksToBounds = true
}
