//
//  navigationItem.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 12/02/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit

class navigationItem: UINavigationItem {

}
