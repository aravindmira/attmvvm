//
//  CardView.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 14/02/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit

class CardView: UIView {
    override func layoutSubviews() {
        layer.cornerRadius = 10
        var color : UIColor = UIColor.black
        layer.shadowColor = color.cgColor
        layer.shadowOffset = CGSize(width: 0, height: 5)
        let shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: 2)
        layer.shadowPath = shadowPath.cgPath
        layer.shadowOpacity = Float(0.5)
        
    }
   
}
