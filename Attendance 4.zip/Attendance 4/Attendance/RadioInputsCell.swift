//
//  RadioInputsCell.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 24/02/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit

class RadioInputsCell: UITableViewCell {

    @IBOutlet weak var RadioImg: UIImageView!
    @IBOutlet weak var TitleLbl: UILabel!
    @IBOutlet weak var oddBT: UIButton!
    @IBOutlet weak var evenBT: UIButton!
    @IBAction func oddBTAction(_ sender: Any) {
        
    }
    @IBAction func evenBTAction(_ sender: Any) {
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
   extension UIButton {
    func addRightImage(name: String, offset: CGFloat) {
       // LASImg.image = UIImage(named: "open.png")
        self.semanticContentAttribute = .forceLeftToRight
        self.setImage(UIImage(named: name), for: .normal)
        self.imageEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 10)
               self.contentHorizontalAlignment = .left
               self.imageView?.contentMode = .scaleAspectFit
    }
}
