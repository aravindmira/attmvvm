//
//  PageViewPV.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 21/02/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit

class PageViewPV: UIPageViewController,UIPageViewControllerDataSource {
    
    
    var TitleLbl = [String]()
    var pageViewController: UIPageViewController!
    var pageIndex: Int = 0
   
    override func viewDidLoad() {
        super.viewDidLoad()
       TitleLbl = ["Data1","Data2","Data3","Data4"]
        // Do any additional setup after loading the view.
         self.dataSource = self
        self.setViewControllers([getViewControllerAtIndex(index: 0)] as [UIViewController], direction: UIPageViewController.NavigationDirection.forward, animated: true, completion: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(PVMoveNextAC), name: .PVMoveNext, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(PVMoveBackAC), name: .PVMoveBack, object: nil)

     
    }
    @objc func PVMoveNextAC(notificaiont: Notification) {
        
        guard let currentViewController = self.viewControllers?.first else { return }
        guard let nextViewController = dataSource?.pageViewController(self, viewControllerAfter: currentViewController) else { return }
        setViewControllers([nextViewController], direction: .forward, animated: true, completion: nil)
    }
    @objc func PVMoveBackAC(notificaiont: Notification) {
 
        guard let currentViewController = self.viewControllers?.first else { return }
        guard let previousViewController = dataSource?.pageViewController(self, viewControllerBefore: currentViewController) else { return }
        setViewControllers([previousViewController], direction: .reverse, animated: true, completion: nil)
         
        }
    func notificationReceived(_ notification: Notification) {

    }
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore PageViewPV: UIViewController) -> UIViewController? {
        let pageContent: PagScrVC = PageViewPV as! PagScrVC
       
        var index = pageContent.pageIndex
        
        if ((index == 0) || (index == NSNotFound))
        {
            return nil
        }

        
        index -= 1;
        return getViewControllerAtIndex(index: index)
    
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter PageViewPV: UIViewController) -> UIViewController? {
        let pageContent: PagScrVC = PageViewPV as! PagScrVC
              
               var index = pageContent.pageIndex
               
               if (index == NSNotFound)
               {
                   return nil;
               }
               index += 1;
               if (index == TitleLbl.count)
               {
                   return nil;
               }
               return getViewControllerAtIndex(index: index)
    }
    func getViewControllerAtIndex(index: NSInteger) -> PagScrVC
    {
        let PSVC = self.storyboard?.instantiateViewController(withIdentifier: "PagScrVC") as! PagScrVC
        PSVC.strTitle = "\(TitleLbl[index])"
        PSVC.pageIndex = index
        PSVC.TotalPage = TitleLbl.count
        return PSVC
    }
    
     
}
extension UIPageViewController {

    func goToNextPage(animated: Bool = true) {
        guard let currentViewController = self.viewControllers?.first else { return }
        guard let nextViewController = dataSource?.pageViewController(self, viewControllerAfter: currentViewController) else { return }
        setViewControllers([nextViewController], direction: .forward, animated: animated, completion: nil)
        
    }

    func goToPreviousPage(animated: Bool = true) {
        guard let currentViewController = self.viewControllers?.first else { return }
        guard let previousViewController = dataSource?.pageViewController(self, viewControllerBefore: currentViewController) else { return }
        setViewControllers([previousViewController], direction: .reverse, animated: animated, completion: nil)
    }

}
extension Notification.Name {
    static let PVMoveNext = Notification.Name("PVMoveNext")
    static let PVMoveBack = Notification.Name("PVMoveBack")
}

